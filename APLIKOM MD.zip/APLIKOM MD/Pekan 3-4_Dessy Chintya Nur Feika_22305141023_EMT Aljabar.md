﻿# Pekan 3-4_Dessy Chintya Nur Feika_22305141023_EMT Aljabar
---



Nama  : Dessy Chintya Nur Feika


NIM   : 22305141023


Kelas : Matematika E 2023


---



Pilih minimal 5 soal dari setiap Latihan atau tipe soal (misalnya
diantara soal-soal yang sudah saya blok). Jangan lupa tuliskan soalnya
di teks komentar (dengan format LaTeX) dan beri penjelasan hasil
output-nya. Ubah file notebook pekerjaan Anda menjadi file PDF
menggunakan salah satu metode di atas.


## R.2 Exercise Set

\>$&((-2/5)^0)

\>$&(a^-2/b^-8)

\>$&(((24\*a^10\*b^-8\*c^7)/(12\*a^6\*b^-3\*c^5))^-5)

\>$&(((125\*p^12\*q^-14\*r^22)/(25\*p^8\*q^6\*r^-15))^-4)

\>$&((2^6\*2^-3)+2^10+2^-8)

\>$&((4\*(8-6)^2-(4\*3)+(2\*8))/(3^1+19^0))

\>$&(([4\*(8-6)^2+4])/(2^2\*(2^3+5)))


## R.3 Excercise Set

\>$&((2\*x+3\*y+z-7)+(4\*x-2\*y-z+8)+(-3\*x+y-2\*z-4))

\>$&((2\*x^2+12\*x\*y-11)+(6\*x^2-2\*x+4)+(-x^2-y-2))

\>$&((3\*x^2-2\*x-x^3+2)-(5\*x^2-8\*x-x^3+4))

\>$&((y-5)^2)

\>$&((n+6)(n-6))

\>$&((3\*x+5\*y)(3\*x-5\*y))


## R.4 Exercise Set

\>$&(t^2+8\*t+15)

\>$&(4\*y^2-5)

\>$&(m^2-9\*n^2)

\>$&(z^2-81), $&solve(z^2-81)

\>$&(x^2+12\*x+36), $&solve(x^2+12\*x+36)


## R.5 Exercise Set

\>$&(7\*(3\*x+6)=11-(x+2)), $&solve(7\*(3\*x+6)=11-(x+2))

\>$&(9\*(2\*x+8)=20-(x+5)), $&solve(9\*(2\*x+8)=20-(x+5))

\>$&(y^2-4\*y-45=0), $&solve(y^2-4\*y-45=0)

\>$&(V=(4/3)\*pi\*r^3)

\>$&(21\*n^2-10=n), $&solve(21\*n^2-10=n)


## R.6 Exercise Set

\>$&((x^2-4)/(x\*2-4\*x+4)), $&solve((x^2-4)/(x\*2-4\*x+4))

\>$&((x\*3-6\*x^2+9\*x)/(x^3-3\*x^2)), $&solve((x\*3-6\*x^2+9\*x)/(x^3-3\*x^2))

\>$&((6\*y^2+12\*y-48)/(3\*y^2-9\*y+6)), $&solve((6\*y^2+12\*y-48)/(3\*y^2-9\*y+6))

\>$&(((r-s)/(r+s)).((r^2-s^2)/(r-s)^2))

\>$&((6-x)/(x^2-36))


## R.7 Exercise Set

\>$&(sqrt(-21)^2)

\>$&(sqrt(9\*y^2))

\>$&(sqrt(180))

\>$&(5\*sqrt(2)+3\*sqrt(32))

\>$&(2\*sqrt(32)+3\*sqrt(8)-4\*sqrt(18))

\>$&(125^(1/3))


## 2.3 Exercise Set

\>$&(h(x)=1/(x-2)^4), $&solve(h(x)=1/(x-2)^4)

\>$&(h(x)=1/sqrt(3\*x+7)), $&solve(h(x)=1/sqrt(3\*x+7))

\>$&(h(x)=(sqrt(x)-3)^4), $&solve(h(x)=(sqrt(x)-3)^4)

\>$&(sqrt((x-5)/(x+2))), $&solve(sqrt((x-5)/(x+2)))


    

\>$&(h(x)=(x+2)^3-5\*(x+2)^2+3\*(x+2)-1), $&solve(h(x)=(x+2)^3-5\*(x+2)^2+3\*(x+2)-1)


## 3.1 Exercise Set

\>$&((-5+3\*i)+(7+8\*i))

\>$&((-5-i)+(6+2\*i))

\>$&((6-4\*i)-(-5+i))

\>$&(sqrt(-4).sqrt(-36))

\>$&(3/(5-11\*i))


## 3.4 Exercise Set

\>$&(1/4+1/5=1/t), $&solve(1/4+1/5=1/t)

\>$&(1/3-5/6=1/x), $&solve(1/3-5/6=1/x)

\>$&((x+2)/4-(x-1)/5=15), $&solve((x+2)/4-(x-1)/5=15)

\>$&((3\*y+5)/(y^2+5\*y)+(y+4)/(y+5)=(y+1)/y)

\>$&(sqrt(3\*x-4)=1), $&solve(sqrt(3\*x-4)=1)


## 3.5 Exercise Set

\>$&(x^2+4\*x-5=0), $&solve(x^2+4\*x-5=0)

\>$&(3\*x^2+2\*x=8), $&solve(3\*x^2+2\*x=8)

\>$&(5\*x^2=15), $&solve(5\*x^2=15)

\>$&(x^2+10=0), $&solve(x^2+10=0)

\>$&((2\*y+5)\*(3\*y-1)=0), $&solve((2\*y+5)\*(3\*y-1)=0)


## Chapter 3 Test

\>$&(x+5\*sqrt(x)-36=0), $&solve(x+5\*sqrt(x)-36=0)

\>$&((3/(3\*x+4))+(2/(x-1))=2), $&solve((3/(3\*x+4))+(2/(x-1))=2)

\>$&(sqrt(x+4)-2=1), $&solve(sqrt(x+4)-2=1)

\>$&(sqrt(x+4)-sqrt(x-4)=2), $&solve(sqrt(x+4)-sqrt(x-4)=2)

\>$&(x^2+4\*x=1), $&solve(x^2+4\*x=1)


## 4.1 Exercise Set

\>$&(f(x)=x^3-9\*x^2+14\*x+24), $&solve(f(x)=x^3-9\*x^2+14\*x+24)

\>$&(f(x)=2\*x^3-3\*x^2+x+6), $&solve(f(x)=2\*x^3-3\*x^2+x+6)

\>$&(g(x)=x^4-6\*x^3+8\*x^2+6\*x-9), $&solve(g(x)=x^4-6\*x^3+8\*x^2+6\*x-9)

\>$&(g(x)=x^4-x^3-3\*x^2+5\*x-2), $&solve(g(x)=x^4-x^3-3\*x^2+5\*x-2)

\>$&(f(x)=(x+3)^2\*(x-1)), $&solve(f(x)=(x+3)^2\*(x-1))


## 4.3 Exercise Set

\>$&((2\*x^4+7\*x^3+x-12)+(x+3))

\>$&((x^3-7\*x^2+13\*x+3)+(x-2))

\>$&((x^3-2\*x^2-8)/(x+2)), $&solve((x^3-2\*x^2-8)/(x+2))

\>$&((x^3-3\*x+10)/(x-2)), $&solve((x^3-3\*x+10)/(x-2))

\>$&((x^4-1)/(x-1)), $&solve((x^4-1)/(x-1))


